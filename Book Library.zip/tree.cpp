#include "tree.h"
#include <iostream>
#include <fstream>
#include <sstream>

//Constructor 
Node::Node(string name) : name(name), bookCount(0), parent(nullptr) {}

//Get the full category path of a node
string Node::getCategory(Node* node) {
    string category = node->name;
    Node* currentNode = node->parent;
    while (currentNode != nullptr) {
        category = currentNode->name + "/" + category;
        currentNode = currentNode->parent;
    }
    return category;
}

// Destructor 
Node::~Node() {
    for (int i = 0; i < children.size(); i++) {
        delete children[i];
    }
    for (int i = 0; i < books.size(); i++) {
        delete books[i];
    }
}

//Constructor to create a new tree with a root node
Tree::Tree(string rootName) {
    root = new Node(rootName);
}

// Destructor
Tree::~Tree() {
    delete root;
}

//Get the root node 
Node* Tree::getRoot() {
    return root;
}

//Insert a new child node under a given node
void Tree::insert(Node* node, string name) {
    Node* newNode = new Node(name);
    newNode->parent = node;
    node->children.push_back(newNode);
}

//Remove a child node with a given name from a node
void Tree::remove(Node* node, string child_name) {
    for (int i = 0; i < node->children.size(); i++) {
        if (node->children[i]->name == child_name) {
            Node* childNode = node->children[i];
            node->children.erase(i);
            delete childNode;
            break;
        }
    }
}

//Check if a node is the root node
bool Tree::isRoot(Node* node) {
    return node == root;
}

//Get a node based on a given path
Node* Tree::getNode(string path) {
    std::stringstream ss(path);
    std::string category;
    Node* currentNode = root;

    while (std::getline(ss, category, '/')) {
        bool found = false;
        for (int i = 0; i < currentNode->children.size(); i++) {
            if (currentNode->children[i]->name == category) {
                currentNode = currentNode->children[i];
                found = true;
                break;
            }
        }
        if (!found) {
            return nullptr;
        }
    }

    return currentNode;
}

//create a new node or return an existing node based on a given path
Node* Tree::createNode(string path) {
    std::stringstream ss(path);
    
    //Variable to store each category 
    std::string category;

    Node* currentNode = root;
    
    //iterate over each category 
    while (std::getline(ss, category, '/')) {
        //check if the category exists as a child of the current node
        bool found = false;
        
        //Iterate over the children of the current node
        for (int i = 0; i < currentNode->children.size(); i++) {
            //Check if the child node's name matches the current category
            if (currentNode->children[i]->name == category) {
                
                currentNode = currentNode->children[i]; //update
                found = true;
               
                break;
            }
        }
        
        //If the category is not found as a child of the current node
        if (!found) {
            //create a new node with the current category
            Node* newNode = new Node(category);
            
            newNode->parent = currentNode;//Set the parent of the new node to the current node
          
            currentNode->children.push_back(newNode);  //Add the new node as a child of the current node
    
            currentNode = newNode; //update the current node to the newly created node
        }
    }
    
    return currentNode;
}

// Get a child node with a given name from a node
Node* Tree::getChild(Node* ptr, string childname) {
    for (int i = 0; i < ptr->children.size(); i++) {
        if (ptr->children[i]->name == childname) {
            return ptr->children[i];
        }
    }
    return nullptr;
}

//Update the book count of a node and its ancestors
void Tree::updateBookCount(Node* ptr, int offset) {
    //Update the book count of the current node
    ptr->bookCount += offset;
    
    //traversing the parent nodes
    Node* currentNode = ptr->parent;
    
    //continue updating the book count of parent nodes until the root is reached
    while (currentNode != nullptr) {
 
        currentNode->bookCount += offset; //Update the book count of the current parent node
        
        //move to the next parent node
        currentNode = currentNode->parent;
    }
}

Book* Tree::findBook(Node* node, string bookTitle) {
    // Check if the book is in the current node
    for (int i = 0; i < node->books.size(); i++) {
        if (node->books[i]->title == bookTitle) {
            return node->books[i];
        }
    }

    // Recursively search for the book in the child nodes
    for (int i = 0; i < node->children.size(); i++) {
        Book* book = findBook(node->children[i], bookTitle);
        if (book != nullptr) {
            return book;
        }
    }

    
    return nullptr;
}


bool Tree::removeBook(Node* node, string bookTitle) {
    //check if the book is in the current node
    for (int i = 0; i < node->books.size(); i++) {
        if (node->books[i]->title == bookTitle) {
            Book* book = node->books[i];
            node->books.erase(i);
            delete book;
            updateBookCount(node, -1);

            //remove empty nodes recursively
            removeEmptyNodes(node);

            return true;
        }
    }

    //recursively search for the book in the child nodes
    for (int i = 0; i < node->children.size(); i++) {
        if (removeBook(node->children[i], bookTitle)) {
            return true;
        }
    }
    return false;
}

void Tree::removeEmptyNodes(Node* node) {
    // Base case
    if (node == root) {
        return;
    }

    // If the current node has no books and no children, remove it from its parent
    if (node->books.empty() && node->children.empty()) {
        Node* parent = node->parent;
        for (int i = 0; i < parent->children.size(); i++) {
            if (parent->children[i] == node) {
                parent->children.erase(i);
                delete node;
                break;
            }
        }

        //recursively remove empty parent nodes
        removeEmptyNodes(parent);
    }
}

//print all books in a node and its children recursively
void Tree::printAll(Node* node) {
    for (int i = 0; i < node->books.size(); i++) {
        node->books[i]->display();
        std::cout << "---" << std::endl;
    }
    for (int i = 0; i < node->children.size(); i++) {
        printAll(node->children[i]);
    }
}

//check if a node is the last child of its parent
bool Tree::isLastChild(Node* ptr) {
    if (ptr->parent == nullptr) {
        return true;
    }
    Node* parent = ptr->parent;
    return parent->children[parent->children.size() - 1] == ptr;
}

void Tree::print()  
{
    print_helper("","",root);
}
//==========================================================================
void Tree::print_helper(string padding, string pointer,Node *node) //helper method for the print method
{
    if (node != nullptr) 
    {

        cout <<padding<<pointer<<node->name<<"("<<node->bookCount<<")"<<endl;

        if(node!=root)  padding+=(isLastChild(node)) ? "   " : "│  ";

        for(int i=0; i<node->children.size(); i++)  //remove the file/folder from original path
        {
            string marker = isLastChild(node->children[i]) ? "└──" : "├──";
            print_helper(padding,marker, node->children[i]);
        }
    }
}

//xpeort all books in a node and its children to a file
int Tree::exportData(Node* node, std::ofstream& file) {
    int count = 0;
    for (int i = 0; i < node->books.size(); i++) {
        Book* book = node->books[i];
        file << book->title << "," << book->author << "," << book->isbn << ","
             << book->publication_year << "," << node->getCategory(node) << ","
             << book->total_copies << "," << book->available_copies << std::endl;
        count++;
    }
    for (int i = 0; i < node->children.size(); i++) {
        count += exportData(node->children[i], file);
    }
    return count;
}